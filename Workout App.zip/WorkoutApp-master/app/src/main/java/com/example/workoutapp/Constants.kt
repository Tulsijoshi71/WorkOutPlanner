package com.example.workoutapp

object Constants {
    val USERNAME = "Username"
    val PASSWORD = "Password"
}